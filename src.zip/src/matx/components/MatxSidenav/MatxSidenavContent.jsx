import React from "react";

const MatxSidenavContent = ({ children }) => {
  return <div className={`matx-sidenav-content h-full`}>{children}</div>;
};

export default MatxSidenavContent;
