import React from "react";

const MatxSidenavContainer = ({ children }) => {
  return <div className="matx-sidenav-container">{children}</div>;
};

export default MatxSidenavContainer;
