import { all, call, fork, put, takeEvery, apply } from 'redux-saga/effects'
import { loginConstant, generalConstant } from '../../constant/ActionTypes'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import {
    API_URL_LOGIN,
    API_URL,
    LOGIN_API,
    PASS_UP,
    headers,
    headers1,
    FWT_PASS,
    CANG_PASS,
    generalFunction,
    loginheaders,
} from '../../constant/Common'
import { LOGIN_ERROR } from '../../constant/ErrorConstant'
import { history } from '../Store'
//import { reactLocalStorage } from "reactjs-localstorage";
import { NotificationManager } from 'react-notifications'
function* userSignProcess(prop) {
    console.log('sagauser', prop)
    let data = prop.payload
    const form = new FormData()
    form.set('username', data['username'])
    form.set('password', data['password'])
    var res = yield axios
        .post(API_URL_LOGIN.api + LOGIN_API, form, {
            headers: loginheaders,
        })
        .then((response) => {
            return response
        })
        .catch((err) => {
            return err.response
        })

    if (res.status === 200) {
        history.push('/')
        res = res.data.response
        if (res.status === 1) {
            localStorage.setItem('user_id', res.data.loginId)
            localStorage.setItem('tokenId', res.data.token)
            localStorage.setItem('auth_user', JSON.stringify(res.data))
            sessionStorage.setItem('tokenId', res.data.token)
            console.log('sagaput', res.data)
            yield put({
                type: loginConstant.LOGIN_SUCCESS,
                payload: res.data,
            })
        } else if (res.status === 100) {
            yield put({
                type: loginConstant.CHANGE_PASSWORD,
                payload: res.data,
            })
            yield call(history.push, '/sess/cngPass')
        } else {
            NotificationManager.error(res.message)
            yield put({
                type: loginConstant.LOGIN_ERROR,
                payload: { error: res.message },
            })
        }
    } else {
        NotificationManager.error(res.message)
        yield put({
            type: loginConstant.LOGIN_ERROR,
            payload: { error: 'Something went wrong' },
        })
    }
}
function* passwordUpdate(prop) {
    let data = prop.payload
    console.log(data)

    const form = new FormData()
    form.set('tempPassword', data['tempPassword'])
    form.set('newPassword', data['newPassword'])
    form.set('confirmPassword', data['confirmPassword'])
    form.set('userId', data['userId'])
    var res = yield axios
        .post(API_URL_LOGIN.api + PASS_UP, form, {
            headers: headers,
        })
        .then((response) => {
            return response
        })
        .catch((err) => {
            return err.response
        })

    if (res.status === 200) {
        res = res.data.response

        if (res.status === 1) {
            yield put({
                type: loginConstant.CHANGE_PASSWORD_SUCCESS,
                payload: { error: res.message },
            })
            yield call(history.push, '/session/signin')
        } else {
            yield put({
                type: loginConstant.LOGIN_ERROR,
                payload: { error: res.message },
            })
        }
    } else {
        yield put({
            type: loginConstant.LOGIN_ERROR,
            payload: { error: 'Something went wrong' },
        })
    }
}

function* forgetPasswordUpdate(prop) {
    let data = prop.payload
    const form = new FormData()
    form.set('username', data['username'])

    var res = yield axios
        .post(API_URL_LOGIN.api + FWT_PASS, form, {
            headers: headers,
        })
        .then((response) => {
            return response
        })
        .catch((err) => {
            return err.response
        })

    if (res.status === 200) {
        res = res.data.response

        if (res.status === 1) {
            yield put({
                type: loginConstant.CHANGE_PASSWORD_SUCCESS,
                payload: { error: res.message },
            })
            yield call(history.push, '/session/signin')
        } else {
            yield put({
                type: loginConstant.LOGIN_ERROR,
                payload: { error: res.message },
            })
        }
    } else {
        yield put({
            type: loginConstant.LOGIN_ERROR,
            payload: { error: 'Something went wrong' },
        })
    }
}
function* dialogPassUp(prop) {
    let data = prop.payload
    const form = new FormData()
    form.set('confirmPassword', data['confirmPassword'])
    form.set('newPassword', data['newPassword'])
    form.set('userId', data['userId'])
    var res = yield axios
        .post(API_URL.api + CANG_PASS, form, {
            headers: headers,
        })
        .then((response) => {
            return response
        })
        .catch((err) => {
            return err.response
        })

    if (res.status === 200) {
        res = res.data.response

        if (res.status === 1) {
            yield put({
                type: loginConstant.DIALOG_CHANGE_PASSWORD_SUCCESS,
                payload: { error: res.message },
            })
            NotificationManager.success(res.message)
        } else {
            yield put({
                type: loginConstant.DIALOG_CHANGE_PASSWORD_ERROR,
                payload: { error: res.message },
            })
            NotificationManager.error(res.message)
        }
    } else {
        yield put({
            type: loginConstant.LOGIN_ERROR,
            payload: { error: 'Something went wrong' },
        })
        NotificationManager.error('Something went wrong')
    }
}
function* signout() {
    console.log('Signout called')
    localStorage.clear()
    yield call(history.push, '/', '')
}
function* actionLoginRequestWatcher() {
   // console.log('ssdvdsvdsvdsvssvsvvsvs')
    yield takeEvery(loginConstant.LOGIN_REQUEST, userSignProcess)
}
function* actionChangePasswordRequestWatcher() {
    yield takeEvery(loginConstant.CHANGE_PASSWORD_REQUEST, passwordUpdate)
}
function* actionForgetPasswordWatcher() {
    yield takeEvery(loginConstant.FORGET_PASSWORD_REQUEST, forgetPasswordUpdate)
}
function* actionSignOutWatcher() {
    yield takeEvery(loginConstant.SIGNOUT, signout)
}
function* actionDialogChangePasswordWatcher() {
    yield takeEvery(loginConstant.DIALOG_CHANGE_PASSWORD_REQUEST, dialogPassUp)
}
export default function* rootSaga() {
    yield all([
        actionLoginRequestWatcher(),
        actionChangePasswordRequestWatcher(),
        actionForgetPasswordWatcher(),
        actionSignOutWatcher(),
        actionDialogChangePasswordWatcher(),
    ])
}
