import React from "react";
//import { authRoles } from "../../auth/authRoles";
import { generalFunction } from "app/constant/Common";
//import Loadable from "app/components/Loadable/Loadable";
const RoleMenu = React.lazy(() => import("./roleMenu"));



const adminRoutes1 = [
  {
    path: "/admin/roleMenu",
    // component: React.lazy(() => import("./roleMenu")),
    menuId: 0,
    element:<RoleMenu/>
  },
];
const menus = localStorage.getItem("menuId");
const enableMenu = generalFunction.decryptedString(menus);
//console.log("jdjd",enableMenu)
var adminRoutes = adminRoutes1.filter(function (element) {
  return enableMenu.includes(element.menuId);
});
//console.log("adminnnnn",adminRoutes)
export default adminRoutes;
