import React from "react";
import { generalFunction } from "app/constant/Common";
const ModetatorList = React.lazy(() => import("./ModetatorList"));
const UserProfile = React.lazy(() => import("./userProfile"));

const moderatorRoutes1 = [
  {
    path: "/mod/post",
    //component: React.lazy(() => import("./ModetatorList")),
    menuId: 6,
    element:<ModetatorList/>
  },
  {
    path: "/mod/prof",
  //  component: React.lazy(() => import("./userProfile")),
    menuId: 0,
    element:<UserProfile/>
  },
  ];
const menus = localStorage.getItem("menuId");
const enableMenu = generalFunction.decryptedString(menus);
var moderatorRoutes = moderatorRoutes1.filter(function (element) {
  return enableMenu.includes(element.menuId);
});


export default moderatorRoutes;
