export { default } from './AddPost';
